Data="Some secret info"
class User{
    constructor(name,email){
        this.name=name
        this.email=email

    }
    viewData(){
        console.log("Data =", Data)
    }
}
class Admin extends User{
    constructor(name,email){
        super(name,email);
    }
    editData(){
        Data="Some Data"

    }
}
let student1=new User("sasi","123@gmail.com");
let admin=new Admin("Nani","nani@gmail.com")